<link href='bac.css' rel='stylesheet' >
<html>
<header>
<title>hi</title>
</header>
<body>
<center><form action="ss.php" method ="post">
<input type="text" name="search" placeholder="name or id"/>
<input type="submit" value="search now"/>
</form></center>
</body>
</html>




