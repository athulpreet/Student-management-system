<?php

ob_start();
include "db_connection.php";
include "functions.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Management System</title>
    <script src="Resources/Script.js"></script>
</head>
<body>

<center><h1><a href="index.php">Student Management System</a></h1></center>