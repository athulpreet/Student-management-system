<?php


    $addingStudent = false;

    if (!isset($studentModel)) {
        $studentModel = new StudentModel("", "", "", "", "", "");
        $addingStudent = true;
    }

?>

<form action="#" method="post">
    <fieldset>
        <legend>Details:</legend>
        <div class="label-input-wrapper">
            <label for="name">Name: </label>
            <input type="text" name="name" placeholder="Enter Name"
            <?php if(!$addingStudent) echo "value='{$studentModel->getName()}'"; ?> required>
        </div>
        <div class="label-input-wrapper">
            <label for="surname">Surname: </label>
            <input type="text" name="surname" placeholder="Enter Surname"
                <?php if(!$addingStudent) echo "value='{$studentModel->getSurname()}'"; ?> required>
        </div>
        <div class="label-input-wrapper">
            <label for="date-of-birth">Date of Birth: </label>
            <input type="date" name="date-of-birth"
                <?php if(!$addingStudent) echo "value='{$studentModel->getDateOfBirth()}'"; ?> required>
        </div>
        <div class="label-input-wrapper">
            <label for="id">ID Number:</label>
            <input type="text" name="id" placeholder="Enter Id Number"
                <?php if(!$addingStudent) echo "value='{$studentModel->getIdNumber()}'"; ?> required>
        </div>

            <?php

                if($addingStudent) {
                    ?>
                        <div class="label-input-wrapper">
                            <label for="class">Class: </label>
                            <?php GetAllClassesAndOutputSelect(); ?>
                        </div>

                    <?php
                }
            ?>
        <div class="label-input-wrapper">
            <label for="Semester">Semester: </label>
            <input list="browsers" name="level">
  <datalist id="browsers">
    <option value="1">
    <option value="3">
    <option value="5">
  </datalist>
                <?php if(!$addingStudent)  ?> 
        </div>
    </fieldset>
    <?php if($addingStudent) include "address_form.php"; ?>
    <?php

    $formValue = "";
    $submitName = "";

    if(!$addingStudent) {
        $submitName = "update_student_details";
        $formValue = "Update";
    } else {
        $submitName = "add_student";

        $formValue = "Add";
    }

    ?>
    <a href="index.php"><input type="submit" value="<?php  echo $formValue ?>" name="<?php echo $submitName; ?>"></a>
</form>
