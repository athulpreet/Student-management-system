<?php

class Data
{
    protected $Id;

    /**
     * Data constructor.
     * @param $Id
     */
    public function __construct($Id)
    {
        $this->Id = $Id;
    }


    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->Id;
    }

    /**
     * @param mixed $Id
     */
    public function setId($Id): void
    {
        $this->Id = $Id;
    }


}