
<link href='bac.css' rel='stylesheet' >
<html>
<header>
<title>student management system</title>
</header>
<body>
<center><h1>STUDENT MANAGEMENT SYSTEM</h1></center>
<center><table>
<tr><form action="login.php">
    <input type="submit" value="ADMIN" style="height:200px; width:200px;background-color:#bfff00;" />
</form>
</tr>
<tr><form action="searchh.php">
    <input type="submit" value="STUDENT" style="height:200px; width:200px;background-color:#C233FF;" />
</form>
</tr>

<table></center>
<body>
</html>