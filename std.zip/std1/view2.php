<link href='bacc2.css' rel='stylesheet' >
<style>
table, th, td{
    height: 50px;
}
</style>
<h1 align="center">BBM STUDENTS</h1>

<?php 

$con=mysqli_connect('localhost','root','system123','student management system');

	function showdata(){
		global $con;
		
		$query="SELECT f.Id,f.Name,f.Surname,f.DateOfBirth,f.Level FROM students f INNER JOIN student_class_mapper d ON f.Id=d.StudentId WHERE d.ClassId=3 ";
        $run= mysqli_query($con,$query);
            if($run==TRUE)
			{ 
		?>
		
		<center><table style="width:70%">
		<tr align="center">
		<td>ID</td><td>NAME</td><td>SURNAME</td><td>DateOfBirth</td><td>SEMISTER</td>
		</tr>
		<?php
		while($data=mysqli_fetch_assoc($run))
		{?>
	
	<tr align="center">
	<td><?php echo $data['Id'];?></td><td><?php echo $data['Name'];?></td><td><?php echo $data['Surname'];?></td><td><?php echo $data['DateOfBirth'];?></td><td><?php echo $data['Level'];?></td>
	</tr>
	<?php
				
			}
			?></table></center><?php
			}
			else
			{
				echo "error";
			}
		
		
		
		
		
		
	}


?>
<html>
            <head>
            <title>show data</title>
            </head>
	<body>
	
	
	<?php showdata(); ?>
	
	<center><form action="admin.php">
    <input type="submit" value="BACK" />
</form></center>
	</body>
</html>