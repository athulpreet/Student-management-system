<link href='bacc2.css' rel='stylesheet' >
<?php


include "includes/header.php";


DeleteStudent();

include "includes/footer.php";