
<link href='bac.css' rel='stylesheet' >
<?php 
$search = $_POST['search'];
$con=mysqli_connect('localhost','root','system123','student management system');

	function showdata(){
		global $con;
		global $search;
		$query=" SELECT * FROM students WHERE Name='$search' OR Id='$search'";
        $run= mysqli_query($con,$query);
            if($run==TRUE)
			{ 
		?>
		
		<center><table style="width:70%">
		<tr align="center">
		<td>ID</td><td>NAME</td><td>SURNAME</td><td>DateOfBirth</td><td>SEMISTER</td><td></td
		</tr>
		<?php
		while($data=mysqli_fetch_assoc($run))
		{?>
	<tr align="center">
	<td><?php echo $data['Id'];?></td><td><?php echo $data['Name'];?></td><td><?php echo $data['Surname'];?></td><td><?php echo $data['DateOfBirth'];?></td><td><?php echo $data['Level'];?></td>
	</tr>
	<?php
				
			}
			?></table></center><?php
			}
			else
			{
				echo "error";
			}
		
		
		
		
		
		
	}


?>
<html>
            <head>
            <title>show data</title>
            </head>
	<body>
	
	
	<?php showdata(); ?>
	
	
	
	</body>
</html>