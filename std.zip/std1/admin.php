
<?php session_start();
if($_SESSION['uuid'])
{
	echo "";
	}
else
{
	header('location:login.php');
}
	

   ?>


<?php include "includes/header.php"; ?>
<link href='bac.css' rel='stylesheet' >
<a href="logout.php" style="float: right;">logout</a>
<center><h2>Student:</h2>
<p> Here you'll find a list overview of student details that can be managed: </p></center>

<?php include "includes/student-list-table.php"; ?>

<div class="button-list-wrapper" align="bottom">
    <a href="add-student.php">Add New Student</a>
</div>


<center><table>
<tr><form action="view.php">
    <input type="submit" value="BCA" />
</form>
</tr>
<tr><form action="view1.php">
    <input type="submit" value="BCOM" />
</form>
</tr>
<tr><form action="view2.php">
    <input type="submit" value="BBM" />
</form>
</tr>
<table></center>


<?php include "includes/footer.php"; ?>
